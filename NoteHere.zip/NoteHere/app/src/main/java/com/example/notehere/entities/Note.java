package com.example.notehere.entities;

import android.os.Parcel;
import android.os.Parcelable;

public class Note implements Parcelable {

    private String title;
    private String dateTime;
    private String subTitle;
    private String noteText;
    private int noteAuthentication;

    public Note(String title, String dateTime, String subTitle, String noteText, int noteAuthentication){
        this.title = title;
        this.subTitle = subTitle;
        this.dateTime = dateTime;
        this.noteText = noteText;
        this.noteAuthentication = noteAuthentication;
    }

    public String getTitle() {
        return title;
    }

    public String getDateTime() {
        return dateTime;
    }

    public String getSubTitle() {
        return subTitle;
    }

    public String getNoteText() {
        return noteText;
    }

    public int getNoteAuthVal(){
        return noteAuthentication;
    }


    protected Note(Parcel in) {
        title = in.readString();
        dateTime = in.readString();
        subTitle = in.readString();
        noteText = in.readString();
        noteAuthentication = in.readInt();
    }

    public static final Creator<Note> CREATOR = new Creator<Note>() {
        @Override
        public Note createFromParcel(Parcel in) {
            return new Note(in);
        }

        @Override
        public Note[] newArray(int size) {
            return new Note[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(dateTime);
        dest.writeString(subTitle);
        dest.writeString(noteText);
        dest.writeInt(noteAuthentication);
    }
}
