package com.example.notehere.listeners;

import com.example.notehere.entities.Note;

public interface NoteListener {
    void onNoteClicked(Note note, int position);            //update notes
    void onNoteLongClicked(Note note,int position);         //delete notes
}
