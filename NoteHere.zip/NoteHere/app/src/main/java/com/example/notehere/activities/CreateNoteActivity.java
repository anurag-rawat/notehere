package com.example.notehere.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.example.notehere.R;
import com.example.notehere.entities.Note;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CreateNoteActivity extends AppCompatActivity {

    private String noteTitle, noteSubTitle, noteContent, noteDateTime;
    private int noteAuth;

    private EditText title, subTitle, content;
    private TextView datetime;
    private Switch authVal;

    private TextView saveNote;

    private Note existingNote;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_note);

        ImageView imageBack = (ImageView) findViewById(R.id.backimage);
        imageBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        title = (EditText) findViewById(R.id.notetitle);
        subTitle = (EditText) findViewById(R.id.notesubtitle);
        content = (EditText) findViewById(R.id.notesContent);
        datetime = (TextView) findViewById(R.id.datetime);

        authVal = (Switch) findViewById(R.id.auth_chck);
        authVal.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    noteAuth = 1;
                    authVal.setText("Unlock Note");
                } else {
                    noteAuth = 0;
                    authVal.setText("Lock Note");
                }
            }
        });

        datetime.setText(
                new SimpleDateFormat("dd MMMM yyyy HH:mm a", Locale.getDefault())
                        .format(new Date())
        );

        saveNote = (TextView) findViewById(R.id.save);
        saveNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                noteTitle = title.getText().toString().trim();
                noteSubTitle = subTitle.getText().toString().trim();
                noteContent = content.getText().toString().trim();
                noteDateTime = datetime.getText().toString().trim();

                if(!noteTitle.isEmpty()) {
                    Note note = new Note(noteTitle, noteDateTime, noteSubTitle, noteContent, noteAuth);
                    Intent i = new Intent(CreateNoteActivity.this, MainActivity.class);
                    i.putExtra("noteData", note);
                    setResult(RESULT_OK, i);
                    finish();
                }else{
                    Toast.makeText(getApplicationContext(),"Note Title Can't be empty.",Toast.LENGTH_SHORT).show();
                }
            }
        });

        if (getIntent().getBooleanExtra("isViewOrUpdate", false)) {
            existingNote = (Note) getIntent().getParcelableExtra("noteData");
            setViewOrUpdateNote();
        }
    }

    private void setViewOrUpdateNote() {
        title.setText(existingNote.getTitle());
        subTitle.setText(existingNote.getSubTitle());
        content.setText(existingNote.getNoteText());
        datetime.setText(existingNote.getDateTime());
        if (existingNote.getNoteAuthVal() == 1) {
            authVal.setChecked(true);
        } else {
            authVal.setChecked(false);
        }
    }

}
