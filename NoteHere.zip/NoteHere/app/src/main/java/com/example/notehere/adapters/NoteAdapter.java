package com.example.notehere.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.notehere.R;
import com.example.notehere.entities.Note;
import com.example.notehere.listeners.NoteListener;

import java.util.ArrayList;
import java.util.Timer;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder> implements Filterable {

    private ArrayList<Note> mNoteList;
    private ArrayList<Note> noteSource;
    private NoteListener noteListener;

    public NoteAdapter(ArrayList<Note> noteList, NoteListener noteListener) {
        this.mNoteList = noteList;
        this.noteListener = noteListener;
        this.noteSource = noteList;
    }

    public static class NoteViewHolder extends RecyclerView.ViewHolder {

        public TextView textTitle, textDateTime;
//        public TextView textSubTitle;
        public LinearLayout noteLayout;

        public NoteViewHolder(@NonNull View itemView) {
            super(itemView);
            textTitle = itemView.findViewById(R.id.textTitle);
//            textSubTitle = itemView.findViewById(R.id.textSubTitle);
            textDateTime = itemView.findViewById(R.id.textDateTime);
            noteLayout = itemView.findViewById(R.id.notesLayout);
        }
    }

    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_container_notes, parent, false);
        return new NoteViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {
        Note currentItem = mNoteList.get(position);

        holder.textTitle.setText(currentItem.getTitle());
//        if (currentItem.getSubTitle().trim().isEmpty())
//            holder.textSubTitle.setVisibility(View.GONE);
//        else
//            holder.textSubTitle.setText(currentItem.getSubTitle());
        holder.textDateTime.setText(currentItem.getDateTime().substring(0,currentItem.getDateTime().length()-8));

        holder.noteLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                noteListener.onNoteClicked(mNoteList.get(position), position);
            }
        });

        holder.noteLayout.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                noteListener.onNoteLongClicked(mNoteList.get(position), position);
                return false;
            }
        });
    }

    @Override
    public int getItemCount() {
        return mNoteList.size();
    }

    @Override
    public Filter getFilter() {
        return noteDataFilter;
    }

    private Filter noteDataFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            ArrayList<Note> filteredList = new ArrayList<>();
            if (constraint == null || constraint.length() == 0) {
                filteredList = noteSource;
            } else {
                String filerPattern = constraint.toString().toLowerCase().trim();
                for (Note item : noteSource) {
                    if (item.getTitle().toLowerCase().contains(filerPattern))
                        filteredList.add(item);
                }
            }
            FilterResults filterResults = new FilterResults();
            filterResults.values = filteredList;
            return filterResults;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            mNoteList = (ArrayList<Note>) results.values;
            notifyDataSetChanged();
        }
    };


}
