package com.example.notehere.activities;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.notehere.R;
import com.example.notehere.adapters.NoteAdapter;
import com.example.notehere.entities.Note;
import com.example.notehere.listeners.NoteListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class HomeScreenActivity extends AppCompatActivity implements NoteListener {

    public static final int REQUEST_CODE_ADD_NOTE = 1;
    public static final int REQUEST_CODE_UPDATE_NOTE = 2;

    ArrayList<Note> mNoteList;
    private RecyclerView recyclerView;
    private NoteAdapter noteAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private Note note;
    private Dialog dialogDeleteNote = null;

    //Variables for Authentication
    private HomeScreenActivity activity = this;

    private BiometricPrompt biometricPrompt;
    private Executor executor;
    private int noteClickedPosition = -1;

    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        ImageView addNoteMain = (ImageView) findViewById(R.id.imageAddNotes);
        addNoteMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(
                        new Intent(HomeScreenActivity.this, CreateNoteActivity.class),
                        REQUEST_CODE_ADD_NOTE
                );
            }
        });

        //SEARCHING NOTES
        EditText inputSearch = findViewById(R.id.search_notes);
        inputSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                noteAdapter.getFilter().filter(s);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        loadData();
        buildRecyclerView();


        //AUTHENTICATION SETUP
        executor = Executors.newSingleThreadExecutor();
        biometricPrompt = new BiometricPrompt.Builder(this)
                .setTitle("Biometric authentication")
                .setSubtitle("Login using your biometric credentials")
                .setDescription("Touch the fingerprint sensor")
                .setNegativeButton("cancel", executor, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                }).build();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_ADD_NOTE && resultCode == RESULT_OK) {
            Toast.makeText(getApplicationContext(), "Note Saved", Toast.LENGTH_SHORT).show();
            note = data.getParcelableExtra("noteData");
            saveNote();
        } else if (requestCode == REQUEST_CODE_UPDATE_NOTE && resultCode == RESULT_OK) {
            Toast.makeText(getApplicationContext(), "Note Updated", Toast.LENGTH_SHORT).show();
            mNoteList.remove(noteClickedPosition);
            note = data.getParcelableExtra("noteData");
            saveNote();
            buildRecyclerView();
        }
    }

    //SAVE NOTE
    private void saveNote() {
        insertItem();
        SharedPreferences sp = getSharedPreferences("NOTES", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        Gson gson = new Gson();
        String json = gson.toJson(mNoteList);
        editor.putString("note values", json);
        editor.apply();
    }

    //INSERT NOTE DATA TO ARRAYLIST AND THEN ADD ELEMENT TO ADAPTER
    private void insertItem() {
        mNoteList.add(new Note(note.getTitle(), note.getDateTime(), note.getSubTitle(), note.getNoteText(), note.getNoteAuthVal()));
        noteAdapter.notifyItemInserted(mNoteList.size());
    }

    //LOAD DATA FROM SHAREDPREFERENCES TO RECYCLER VIEW
    public void loadData() {
        SharedPreferences sp = getSharedPreferences("NOTES", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sp.getString("note values", null);
        Type type = new TypeToken<ArrayList<Note>>() {
        }.getType();
        mNoteList = gson.fromJson(json, type);
        if (mNoteList == null) {
            mNoteList = new ArrayList<>();
        }
    }

    //UPDATE NOTES AFTER DELETE
    private void updateNote_AfterDelete() {
        SharedPreferences sp = getSharedPreferences("NOTES", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        Gson gson = new Gson();
        String json = gson.toJson(mNoteList);
        editor.putString("note values", json);
        editor.apply();
    }

    //BUILD THE RECYCLERVIEW FOR ARRAYLIST
    private void buildRecyclerView() {
        recyclerView = findViewById(R.id.notesRecyclerView);
        recyclerView.setHasFixedSize(true);
        mLayoutManager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
        noteAdapter = new NoteAdapter(mNoteList, this);

        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setAdapter(noteAdapter);
    }

    //AUTHENTICATE NOTES
    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    public void onNoteClicked(Note note, int position) {
        if (note.getNoteAuthVal() == 1) {             //Opening Authenticated Notes
            biometricPrompt.authenticate(new CancellationSignal(), executor, new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            noteClickedPosition = position;
                            Intent i = new Intent(HomeScreenActivity.this, CreateNoteActivity.class);
                            i.putExtra("isViewOrUpdate", true);
                            i.putExtra("noteData", note);
                            i.putExtra("position", position);
                            startActivityForResult(i, REQUEST_CODE_UPDATE_NOTE);
                        }
                    });
                }
            });
        } else {                                  //Opening non-Authenticated notes
            noteClickedPosition = position;
            Intent i = new Intent(HomeScreenActivity.this, CreateNoteActivity.class);
            i.putExtra("isViewOrUpdate", true);
            i.putExtra("noteData", note);
            i.putExtra("position", position);
            startActivityForResult(i, REQUEST_CODE_UPDATE_NOTE);
        }
    }

    //REMOVE NOTES
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onNoteLongClicked(Note note, int position) {
        showDeleteDialog(position);
    }
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void showDeleteDialog(int position) {
        dialogDeleteNote = new Dialog(HomeScreenActivity.this);
        dialogDeleteNote.setContentView(R.layout.delete_note_layout);
        dialogDeleteNote.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialogDeleteNote.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialogDeleteNote.setCancelable(false);
        TextView deleteNote = dialogDeleteNote.findViewById(R.id.deleteNote);
        TextView cancelDelete = dialogDeleteNote.findViewById(R.id.cancelDelete);
        deleteNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mNoteList.remove(position);
                buildRecyclerView();
                updateNote_AfterDelete();
                dialogDeleteNote.dismiss();
            }
        });
        cancelDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogDeleteNote.dismiss();
            }
        });
        dialogDeleteNote.show();
    }

}
